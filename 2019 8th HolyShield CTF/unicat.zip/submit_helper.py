#!/usr/bin/python3.7
# -*- coding:utf-8 -*-

# Holyshield 2019 Unicat submit helper
#  
# Usage: python submit_helper.py | nc 1.224.175.31 9980


ans_hello = u"[YOUR UNICAT CODE FOR 'HELLO' HERE]"
ans_add = u"[YOUR UNICAT CODE FOR 'A+B' HERE]"
ans_star = u"[YOUR UNICAT CODE FOR 'Star' HERE]"
print()
print()
print()
print()
print(ans_hello)
print(ans_add)
print(ans_star)