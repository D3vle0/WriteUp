<?php
session_start();
include 'dbconn.php';

$username = mysqli_real_escape_string($conn,$_SESSION['username']);

$iv = "NGA_NGA_NGA_NGA_";

$ip = explode('.',$_SERVER['REMOTE_ADDR']);
$ip = sprintf("%03d.%03d.%03d.%03d", $ip[0], $ip[1], $ip[2], $ip[3]);
$key = $ip."@";

$action = $_POST['action'];

if($action == 'login'){

	include 'login.php';
	login();

}

if($action == 'register'){

	include 'register.php';
	register();
}

if($action == 'write'){

	include 'write.php';
	write_note();

}

if($action == 'logout'){

	include 'logout.php';
	logout();

}



?>
<!DOCTYPE html>
<html>
	<head>
		<title>simple note</title>
		<style>
			#list{
				display: inline-block; 
				width:300px; 
				height:200px; 
				border:1px solid black;
				margin: 0.5em; 
				word-wrap: break-word;
				background-color: #DCDCDC;
			}
		</style>
	</head>
	<body>
	<?php
	if(empty($username)){ ?>
	
	<h1 style="text-align:center">Simple note</h1>
        <form action="" method="POST" align="center">

                ID <input type="text" name="username">
                <button type="submit" name="action" value="login">login</button>
                <br>
                PW <input type="password" name="password">
                <button type="submit" name="action" value="register">register</button>
                <br>

        </form>
	
 	 <?php
	} 
	else {
		# index
		if(empty($action) || $action == 'index'){

			include 'list.php';
			echo "	<h1>User: {$username}</h1>";

		?>
		<form method='POST'>
		<button type='submit' name='action' value='add'>write</button>
		<button type='submit' name='action' value='logout'>logout</button>
		<button type='submit' name='order' value='title asc'>title sort</button>
		</form>

	<?php 
			$req = show_list();
			echo "	<form method='POST'>";
			echo "	<input type='hidden' name='action' value='read'>";
			while($row = mysqli_fetch_array($req)){ 
	?>
 	<button type="submit" name="no" value="<?php echo $row['no'];?>">
		<div id="list">
			<div><?php echo $row['title']; ?></div>
			<br>
			<div><?php if(substr($row['ip'],0,8) == substr($ip,0,8)) echo openssl_decrypt($row['contents'], 'AES-128-CBC', $key,0,$iv);?></div>
		</div>
	</button>
	<?php 
			}
			echo "	</form>";

		}
		# read
		if($action == 'read'){
			
			include	'read.php';
			$row = mysqli_fetch_array(note_read());
	
	?>
	<br><br>
	<div align="center">
	<form method="POST">
		<div class="form-group">
			<label>title</label>
			<br>
			<div>
				<input type="text" value="<?php echo $row['title']?>" size="35" disabled>
        	  	</div>
        		<label>contents</label>
			<br>
        		<div>
        		   	<textarea rows="10" cols="37" disabled><?php if(substr($row['ip'],0,8) == substr($ip,0,8)) echo openssl_decrypt($row['contents'], 'AES-128-CBC', $key,0,$iv);?></textarea>
        		</div>
        		<br> 
			<div>
				<button onlick="location='';">back</button>
            		</div>
		</div>
        </form>
	</div>
	<?php 
		}
		# add
		if($action == 'add'){
	?>
	<br><br>
 	<div align="center">
        <form method="POST">
                <div class="form-group">
                        <label>title</label>
                        <br>
                        <div>
                                <input type="text" name="title" size="35">
                        </div>
                        <label>contents</label>
                        <br>
                        <div>
                                <textarea name="contents" rows="10" cols="37"></textarea>
                        </div>
                        <br>
                        <div>
                                <button name="action" value="write">write</button>
                                <button onlick="location='';">back</button>
                        </div>
                </div>
        </form>
        </div>


	<?php
		}
	} 
	?>
	
	</body>
</html>

