<?php

$host='localhost';
$user=SOMETHINGS;
$pass=SOMETHINGS;
$db='simple_note';

$conn = mysqli_connect($host,$user,$pass,$db) or die('DB is Die');

?>
