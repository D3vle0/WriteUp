<?php

function login(){

	global $conn;

	if(empty($_POST['username']) || empty($_POST['password'])){

		exit("<script>alert('Username or Password is empty');location=''</script>");
	}
	
	$username=mysqli_real_escape_string($conn,$_POST['username']);
	$password=sha1($_POST['password']);
	
	
	$query = "select * from users where id='{$username}' and pw='{$password}'";
	$req = mysqli_query($conn,$query);
	$row = mysqli_fetch_array($req);


	if(isset($row)){

		$_SESSION['username'] = $row['id'];
		echo "<script>alert('Login Success!');location='';</script>";
	}
	else{

		echo "<script>alert('Login Fail!');location='';</script>";

	}

}

?>
