<?php

function register(){

	global $conn;

	$username=mysqli_real_escape_string($conn,$_POST['username']);
	$password = $_POST['password'];

	if(empty($username) || empty($password))
		die("<script>alert('username or password is empty');location='';</script>");

	$password=sha1($password);
	
	$query = "select * from users where id='{$username}'";
	$req = mysqli_query($conn,$query);
	$row = mysqli_fetch_array($req);

	if(isset($row)){
	
		echo "<script>alert('Aready exist id!');</script>";
	
	}
	else{
	
		$query = "insert into users(id,pw) values('{$username}','{$password}')";
		$req = mysqli_query($conn,$query) or die("<script>alert('something's wrong');location=''</script>");
		echo "<script>alert('register Success!');location='';</script>";
	
	}
	
}


?>
