<?php

function note_read(){

	global $conn;
	global $username;

	$no = mysqli_real_escape_string($conn,$_POST['no']);
	$query = "select * from note where id='{$username}' and no='{$no}'";
	$req = mysqli_query($conn,$query);
	return $req;
}
?>
