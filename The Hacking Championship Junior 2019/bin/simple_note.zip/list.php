<?php

function show_list() {

	global $conn;
	global $username;

	$order = mysqli_real_escape_string($conn,$_POST['order']);
	$st = "";

	if(!empty($order))
		$st = " order by {$order}";

	$query = "select * from note where id='{$username}'".$st;
	$req = mysqli_query($conn,$query);
	return $req;
}

?>
