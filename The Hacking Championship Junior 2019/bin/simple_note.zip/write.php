<?php
function write_note(){

	global $conn;
	global $username;
	global $iv;	
	global $key;
	global $ip;

	if($username == 'admin')
		die("<script>alert('no!');location='';</script>");

	$title = mysqli_real_escape_string($conn,$_POST['title']);
	$contents = mysqli_real_escape_string($conn,$_POST['contents']);

	if(strlen($title) > 50)
		die("<script>alert('title is too long');location='';</script>");

	if(strlen($contents) > 100)
		die("<script>alert('contents is too long');location='';</script>");
	
	$w_ip = substr($ip,0,8).'xxx.xxx';	
	$cipher= openssl_encrypt($contents, 'AES-128-CBC', $key,0,$iv);

	$query = "insert into note(id,title,contents,ip) values('{$username}','{$title}','{$cipher}','{$w_ip}')";
	mysqli_query($conn,$query) or die("<script>alert('something's wrong')location=''</script>");

	echo "<script>alert('write success!');location='';</script>";

}
?>
