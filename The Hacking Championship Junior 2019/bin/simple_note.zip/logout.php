<?php

function logout(){
	session_destroy();
	echo "<script>alert('logout~');location='';</script>";
}
?>
